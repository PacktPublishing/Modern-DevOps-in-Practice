#!/bin/bash

docker build -t $1 .