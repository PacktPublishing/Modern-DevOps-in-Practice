#!/bin/bash
IMAGE=$1
docker build -t $IMAGE .