#!/bin/bash

docker build -t myimage .